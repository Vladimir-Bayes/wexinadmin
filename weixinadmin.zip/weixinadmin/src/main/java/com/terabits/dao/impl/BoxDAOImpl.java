package com.terabits.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.terabits.dao.BoxDAO;
import com.terabits.mapper.BoxMapper;
import com.terabits.meta.po.AdminPO;
import com.terabits.meta.po.BoxPO;
import com.terabits.meta.po.SiteInfoPO;
import com.terabits.meta.vo.BoxVO;
import com.terabits.meta.vo.SiteInfoVO;
import com.terabits.utils.DBTools;

@Repository("BoxDAO")
public class BoxDAOImpl implements BoxDAO {
	
	public AdminPO selectAdminInfoByPhone(String phone) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		AdminPO adminPO = new AdminPO();
		try {
			adminPO = mapper.selectAdminInfoByPhone(phone);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return adminPO;
	}
	
	public int selectTypeByPhone(String phone) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		int type=0;
		try {
			type = mapper.selectTypeByPhone(phone);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return type;
	}
	
	public List<SiteInfoVO> selectSiteInfo(String city) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		List<SiteInfoVO> siteInfoVOs = new ArrayList<SiteInfoVO>();
		try {
			siteInfoVOs = mapper.selectSiteInfo(city);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return siteInfoVOs;
	}
	
	public List<SiteInfoPO> selectSiteByname(String name) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		List<SiteInfoPO> siteInfoPOs = new ArrayList<SiteInfoPO>();
		try {
			siteInfoPOs = mapper.selectSiteByname(name);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return siteInfoPOs;
	}
	
	public boolean checkSitename(String sitename) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		String str="";
		try {
			str = mapper.checkSitename(sitename);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		if (str.equals("") || str.equals(null)) {
			return false;
		} else {
			return true;
		}
	}
	
	public int insertSite(String name, String city, String adminname, String adminphone, 
			int devicequantity, String address,	double longitude, double latitude) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);

		try {
			mapper.insertSite(name, city, adminname, adminphone, devicequantity, address, longitude, latitude);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
			return 400;
		} finally {
			session.close();
		}
		return 200;
	}	
	
	public int updateSiteInfoBySitename(double longitude, double latitude, String siteLocation, String sitename) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		try {
			mapper.updateSiteInfoBySitename(longitude, latitude, siteLocation, sitename);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
			return 400;
		} finally {
			session.close();
		}		
		return 200;
	}
	
	public int updateActivation(int chargeType, String type, int activation, String sitename, String imei) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		try {
			mapper.updateActivation(chargeType, type, activation, sitename, imei);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
			return 400;
		} finally {
			session.close();
		}
		return 200;
	}
	
	public String selectWebIdByImei(String imei) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		String webid="";
		try {
			webid = mapper.selectWebIdByImei(imei);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return webid;
	}
	
	public int unbindDevice(String imei) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		try {
			mapper.unbindDevice(imei);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
			return 0;
		} finally {
			session.close();
		}
		return 1;
	}
	
	public List<BoxPO> selectDeviceBySiteId(int siteid) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		List<BoxPO> boxPOs = new ArrayList<BoxPO>();
		try {
			boxPOs = mapper.selectDeviceBySiteId(siteid);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return boxPOs;
	}
	
	public List<BoxPO> selectDevicesByImei(String imei) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		List<BoxPO> boxPOs = new ArrayList<BoxPO>();
		try {
			boxPOs = mapper.selectDevicesByImei(imei);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return boxPOs;
	}
	
	public int updateDeviceInfoByImei(String mark, String sitename, String imei) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		try {
			mapper.updateDeviceInfoByImei(mark, sitename, imei);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
			return 400;
		} finally {
			session.close();
		}
		return 200;
	}
	
	
	
	
	public List<String> selectCity() throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		List<String> cityList = new ArrayList<String>();
		try {
			cityList = mapper.selectCity();
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return cityList;
	}
	
	public List<String> selectSitename(String city) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		List<String> siteList = new ArrayList<String>();
		try {
			siteList = mapper.selectSitename(city);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		} 
		return siteList; 
	}
	
	public List<BoxVO> selectDevicesBySitename(String sitename) throws Exception {
		SqlSession session = DBTools.getSession();
		BoxMapper mapper = session.getMapper(BoxMapper.class);
		List<BoxVO> boxVOs = new ArrayList<BoxVO>();
		try {
			boxVOs = mapper.selectDevicesBySitename(sitename);
			session.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			session.rollback();
		} finally {
			session.close();
		}
		return boxVOs;
	}

	
}
