package com.terabits.dao;

import java.util.List;

import com.terabits.meta.po.AdminPO;
import com.terabits.meta.po.BoxPO;
import com.terabits.meta.po.SiteInfoPO;
import com.terabits.meta.vo.BoxVO;
import com.terabits.meta.vo.SiteInfoVO;

public interface BoxDAO {
	
	public AdminPO selectAdminInfoByPhone(String phone) throws Exception;
	
	public int selectTypeByPhone(String phone) throws Exception;
	
	public List<SiteInfoVO> selectSiteInfo(String city) throws Exception;
	
	public List<SiteInfoPO> selectSiteByname(String name) throws Exception;
	
	public boolean checkSitename(String sitename) throws Exception;
	
	public int insertSite(String name, String city, String adminname, String adminphone, 
			int devicequantity, String address,	double longitude, double latitude) throws Exception;
	
	public int updateSiteInfoBySitename(double longitude, double latitude, String siteLocation, String sitename) throws Exception;
	
	public int updateActivation(int chargeType, String type, int activation, String sitename, String imei) throws Exception;
	
	public String selectWebIdByImei(String imei) throws Exception;
	
	public int unbindDevice(String imei) throws Exception;
	
	public List<BoxPO> selectDeviceBySiteId(int siteid) throws Exception;
	
	public List<BoxPO> selectDevicesByImei(String imei) throws Exception;
	
	public int updateDeviceInfoByImei(String mark, String sitename, String imei) throws Exception;
	
	
	
	
	public List<String> selectCity() throws Exception;
	
	public List<String> selectSitename(String city) throws Exception;
	
	public List<BoxVO> selectDevicesBySitename(String sitename) throws Exception;
	
	
}
