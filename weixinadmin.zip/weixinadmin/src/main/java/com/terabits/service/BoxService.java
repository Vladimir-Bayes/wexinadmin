package com.terabits.service;

import java.util.List;

import com.terabits.meta.po.AdminPO;
import com.terabits.meta.po.SiteInfoPO;
import com.terabits.meta.vo.BoxInfoVO;
import com.terabits.meta.vo.BoxVO;
import com.terabits.meta.vo.SiteInfoVO;

public interface BoxService {
	
	public AdminPO getAdminInfoByphone(String phone);
		
	public int getTypeByPhone(String phone);
	
	public List<SiteInfoVO> getSiteInfo(String city);
	
	public List<SiteInfoPO> selectSiteByname(String name);
	
	public boolean checkSitename(String sitename);
	
	public int insertNewSite(String name, String city, String adminname, String adminphone, 
			int devicequantity, String address,	double longitude, double latitude);
	
	public int updateSiteInfoBySitename(double longitude, double latitude, String siteLocation, String sitename);
	
	public int updateActivation(int chargeType, String type, int activation, String sitename, String imei);
	
	public String getWebIdByImei(String imei);
	
	public int unbindDevice(String imei);
	
	public int modifyDeviceInfo(String mark, String sitename, String imei);
	
	public List<BoxInfoVO> getBoxInfoBySiteId(int siteid);
	
	public List<BoxInfoVO> getBoxInfoByImei(String imei);
	
	
	
	
	public List<String> selectCity();
	
	public List<String> selectSitename(String city);
	
	public List<BoxVO> getDevicesBySitename (String sitename);
	
	

}
