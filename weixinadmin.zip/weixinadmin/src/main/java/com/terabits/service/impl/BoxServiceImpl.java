package com.terabits.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.terabits.dao.BoxDAO;
import com.terabits.meta.po.AdminPO;
import com.terabits.meta.po.BoxPO;
import com.terabits.meta.po.SiteInfoPO;
import com.terabits.meta.vo.BoxInfoVO;
import com.terabits.meta.vo.BoxVO;
import com.terabits.meta.vo.SiteInfoVO;
import com.terabits.service.BoxService;

@Service
public class BoxServiceImpl implements BoxService {

	@Autowired
	private BoxDAO boxDAO;
	
	public AdminPO getAdminInfoByphone(String phone) {
		try {
			return  boxDAO.selectAdminInfoByPhone(phone);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public int getTypeByPhone(String phone) {
		try {
			return boxDAO.selectTypeByPhone(phone);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return 0;
	}
	
	public List<SiteInfoVO> getSiteInfo(String city) {
		try {
			return boxDAO.selectSiteInfo(city);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public List<SiteInfoPO> selectSiteByname(String name) {
		try {
			return boxDAO.selectSiteByname(name);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean checkSitename(String sitename) {
		try {
			return boxDAO.checkSitename(sitename);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
	
	public int insertNewSite(String name, String city, String adminname, String adminphone, 
			int devicequantity, String address,	double longitude, double latitude) {
		try {
			boxDAO.insertSite(name, city, adminname, adminphone, devicequantity, address, longitude, latitude);
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return 0;
	}	
	
	public int updateSiteInfoBySitename(double longitude, double latitude, String siteLocation, String sitename) {
		try {
			boxDAO.updateSiteInfoBySitename(longitude, latitude, siteLocation, sitename);
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return 0;
	}
	
	public int updateActivation(int chargeType, String type, int activation, String sitename, String imei) {
		try {
			boxDAO.updateActivation(chargeType, type, activation, sitename, imei);
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return 0;
	}
	
	public String getWebIdByImei(String imei) {
		try {
			return boxDAO.selectWebIdByImei(imei);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public int unbindDevice(String imei) {
		try {
			return boxDAO.unbindDevice(imei);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return 0;
	}	
	
	public List<BoxInfoVO> getBoxInfoBySiteId(int siteid) {
		List<BoxInfoVO> boxInfoVOs = new ArrayList<BoxInfoVO>();
		List<BoxPO> boxPOs = new ArrayList<BoxPO>();
		try {
			boxPOs = boxDAO.selectDeviceBySiteId(siteid);
			for (BoxPO boxPO : boxPOs) {
				BoxInfoVO boxInfoVO = new BoxInfoVO();
				boxInfoVO.setMark(boxPO.getMark());
				boxInfoVO.setSelfnumber(boxPO.getSelfnumber());
				boxInfoVOs.add(boxInfoVO);
			}
			return boxInfoVOs;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public List<BoxInfoVO> getBoxInfoByImei(String imei) {
		List<BoxInfoVO> boxInfoVOs = new ArrayList<BoxInfoVO>();
		List<BoxPO> boxPOs = new ArrayList<BoxPO>();
		try {
			boxPOs = boxDAO.selectDevicesByImei(imei);
			for (BoxPO boxPO : boxPOs) {
				BoxInfoVO boxInfoVO = new BoxInfoVO();
				boxInfoVO.setMark(boxPO.getMark());
				boxInfoVO.setSelfnumber(boxPO.getSelfnumber());
				boxInfoVOs.add(boxInfoVO);
			}
			return boxInfoVOs;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public int modifyDeviceInfo(String mark, String sitename, String imei) {
		try {
			boxDAO.updateDeviceInfoByImei(mark, sitename, imei);
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return 0;
	}
	
	
	public List<String> selectCity(){
		try {
			return boxDAO.selectCity();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public List<String> selectSitename(String city) {
		try {
			return boxDAO.selectSitename(city);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public List<BoxVO> getDevicesBySitename(String sitename) {
		try {
			return boxDAO.selectDevicesBySitename(sitename);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}	
}
