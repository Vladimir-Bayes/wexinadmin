package com.terabits.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.terabits.meta.po.AdminPO;
import com.terabits.meta.po.BoxPO;
import com.terabits.meta.po.SiteInfoPO;
import com.terabits.meta.vo.BoxVO;
import com.terabits.meta.vo.SiteInfoVO;

public interface BoxMapper {
	
	public AdminPO selectAdminInfoByPhone(@Param("phone") String phone) throws Exception;
	
	public int selectTypeByPhone(@Param("phone") String phone) throws Exception;
	
	public List<SiteInfoVO> selectSiteInfo(@Param("city") String city) throws Exception;
	
	public List<SiteInfoPO> selectSiteByname(@Param("name") String name) throws Exception;
	
	public String checkSitename(@Param("sitename") String sitename) throws Exception;
	
	public int insertSite(@Param("name") String name, @Param("city") String city, 
			@Param("adminname") String adminname, @Param("adminphone") String adminphone, 
			@Param("devicequantity") int devicequantity, @Param("address") String address, 
			@Param("longitude") double longitude, @Param("latitude") double latitude) throws Exception;
	
	public int updateSiteInfoBySitename(@Param("longitude") double longitude, @Param("latitude") double latitude, @Param("siteLocation") String siteLocation, @Param("siteName") String siteName) throws Exception;
	
	public int updateActivation(@Param("chargeType") int chargeType, @Param("type") String type, @Param("activation") int activation, @Param("sitename") String sitename, @Param("imei") String imei) throws Exception;
	
	public String selectWebIdByImei(@Param("imei") String imei) throws Exception;
	
	public int unbindDevice(@Param("imei") String imei) throws Exception;
	
	public List<BoxPO> selectDeviceBySiteId(@Param("siteid") int siteid) throws Exception;
	
	public List<BoxPO> selectDevicesByImei(@Param("imei") String imei) throws Exception;
	
	public int updateDeviceInfoByImei(@Param("mark") String mark, @Param("sitename") String sitename, @Param("imei") String imei) throws Exception;
	
	
	
	
	public List<String> selectCity() throws Exception;
	
	public List<String> selectSitename(@Param("city") String city) throws Exception;
	
	public List<BoxVO> selectDevicesBySitename(@Param("sitename") String sitename) throws Exception;
	
	
}
