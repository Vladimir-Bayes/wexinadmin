package com.terabits.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.terabits.meta.po.AdminPO;
import com.terabits.meta.po.SiteInfoPO;
import com.terabits.meta.vo.BoxInfoVO;
import com.terabits.meta.vo.SiteInfoVO;
import com.terabits.service.BoxService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
public class BoxController {
	
	@Autowired
	private BoxService boxService;
		
	
	@RequestMapping(value="/massage/sendVerifyCode", method = RequestMethod.POST)
	public JSONObject sendverifycode(@RequestParam(value = "phone") String phone) throws Exception {
		
		AdminPO adminPO = new AdminPO();
		adminPO = boxService.getAdminInfoByphone(phone);
		JSONObject jsonObject = new JSONObject();
		int status=0;
		String auth="";
		if (adminPO==null) {	
//			System.out.println("用户未注册,没有管理员身份");
			jsonObject.put("status", 2);
			return jsonObject;
		}
		if (adminPO.getOpenid()!=null) {
//			System.out.println("用户已绑定");
			jsonObject.put("status", 3);
			return jsonObject;
		}		
		
		/*
		*************************************************************************************
		*******************************对应平台的发短信操作*****************************************
		*********************如果短信发送成功，则将status置为1，并且更改auth*****************************
		*************************************************************************************
		*/		
		
		jsonObject.put("status", status);
		if (status==1) {
			jsonObject.put("auth", auth);
		}
		return jsonObject;
	}
	
	
	@RequestMapping(value="/massage/verification", method = RequestMethod.POST)
	public JSONObject verification(
			@RequestParam(value = "phone") String phone,
			@RequestParam(value = "auth") String auth,
			@RequestParam(value = "code") String code) throws Exception {
		
		JSONObject jsonObject = new JSONObject();
		AdminPO adminPO = new AdminPO();
		adminPO = boxService.getAdminInfoByphone(phone);
		if (adminPO==null) {	
//			System.out.println("用户未注册,没有管理员身份");
			jsonObject.put("status", 0);
			return jsonObject;
		}
		
		int status = 0;
		int type = adminPO.getType();
		String token="";
		int access = 0;
		
		/*
		*************************************************************************************
		***************************对应平台的核对验证码的操作*****************************************
		**********************如果验证成功，则将status置为1，并且更改token*****************************
		***********************如果验证失败，则将status置为相应的错误类型*****************************
		*************************************************************************************
		*/
		
//		if (adminService.authConfirm(type, "/massage/verification")) {
//			access=1;
//		}	
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(0, "/massage/verification");
		jsonArray.add(1, access);
		jsonObject.put("status", status);
		if (status==1) {
			jsonObject.put("type", type);
			jsonObject.put("token", token);
			jsonObject.put("authority", jsonArray);
		}				
		return jsonObject;
	}
	
	
	@RequestMapping(value="/manage/mainpage", method = RequestMethod.GET)
	public JSONObject mainpage(@RequestParam(value = "code") String code) throws Exception {
		
		int status =0;
		int type =0;
		String token="";
		int access =0;

		/*
		*************************************************************************************
		***************************对应了一些平台的操作*****************************************
		************************************************************************************
		*/
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(0, "/manage/mainpage");
		jsonArray.add(1, access);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", status);
		jsonObject.put("type", type);
		jsonObject.put("token", token);
		jsonObject.put("authority", jsonArray);
		
		return jsonObject;
	}
	
	
	@RequestMapping(value="/boxManage/activate", method = RequestMethod.POST)
	public JSONObject activate(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "imei") String imei) throws Exception {
		
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		
		float rssi = 0;
		
		/*
		*************************************************************************************
		***************************对应平台的获取设备信号强度信息**************************************
		************************需要根据输入的IMEI先查找到设备的相关信息*********************************
		*************************之后，再向平台请求该设备的信号强度信息***********************************
		*************************************************************************************
		*/
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		jsonObject.put("signalStrength", rssi);
		return jsonObject;
	}
	
	
	@RequestMapping(value="/boxManage/insertCoins", method = RequestMethod.POST)
	public JSONObject insertcoins(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "imei") String imei,
			@RequestParam(value = "coins") int coins) throws Exception {
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		int insertCoinsResults=0;
		
		/*
		*************************************************************************************
		******************************对应平台的命令下发操作****************************************
		************************需要根据输入的IMEI先查找到设备的相关信息*********************************
		******************************之后，平台向该设备下发命令**************************************
		*************************************************************************************
		*/
		
		jsonObject.put("insertCoinsResults", insertCoinsResults);		
		return jsonObject;
	}
	
	
	@RequestMapping(value = "/boxManage/siteInfo", method = RequestMethod.GET)
	public JSONObject siteinfo(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "city") String city) throws Exception {
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
			
		List<SiteInfoVO> siteInfoVOs = new ArrayList<SiteInfoVO>();
		siteInfoVOs = boxService.getSiteInfo(city);
		JSONArray jsonArray = JSONArray.fromObject(siteInfoVOs);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		jsonObject.put("info", jsonArray);
		return jsonObject;
	}
	
	
	@RequestMapping(value = "/boxManage/uploadInfo", method = RequestMethod.POST)
	public JSONObject uploadinfo(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "imei") String imei,
			@RequestParam(value = "chargeType") int chargeType,
			@RequestParam(value = "type") String type,
			@RequestParam(value = "siteName") String siteName,
			@RequestParam(value = "siteLocation") String siteLocation,
			@RequestParam(value = "longitude") double longitude,
			@RequestParam(value = "latitude") double latitude,
			@RequestParam(value = "deviceLocation") String deviceLocation,
			@RequestParam(value = "deviceNumber") String deviceNumber) throws Exception {
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		
		String city="";
		String adminname="";
		String adminphone="";
		int uploadResult_1=0;
		int uploadResult_2=0;
//		city = adminPO.getCity();
//		adminname = adminPO.getadminname();
//		adminphone = adminPO.getadminphone();
		
		List<SiteInfoPO> siteInfoPOs = new ArrayList<SiteInfoPO>();
		siteInfoPOs = boxService.selectSiteByname(siteName);
		
//		先根据网点名称，查找有没有该网点，如果不存在则会插入该网点，如果存在，则会根据网点名称更新相关信息
		
		if (siteInfoPOs==null) {
			boxService.insertNewSite(siteName, city, adminname, adminphone, 0, siteLocation, longitude, latitude);
//			插入新网点，该网点下的设备在线数量直接置为了0			
		} else {
//			为了运行方便，这两个更新都改成了动态SQL语句了
			uploadResult_1 = boxService.updateSiteInfoBySitename(longitude, latitude, siteLocation, siteName);
			uploadResult_2 = boxService.updateActivation(chargeType, type, 1, siteName, imei);
		}
		
		int uploadResult = uploadResult_1 * uploadResult_2;
//		只有当两个操作都正确时，uploadResult才为1
		jsonObject.put("uploadResult", uploadResult);
		return jsonObject;
		
	}
	
	
	@RequestMapping(value = "/boxManage/QRcodeGenerate", method = RequestMethod.POST)
	public JSONObject qrcodegenerate(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "imei") String imei) throws Exception {
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		
		String webid = "";
		webid = boxService.getWebIdByImei(imei);			
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		jsonObject.put("QRcodeURL", webid);
		return jsonObject;
	}
	
	
	@RequestMapping(value = "/boxManage/unbind", method = RequestMethod.POST)
	public JSONObject unbind(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "imei") String imei) throws Exception {		
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		jsonObject.put("unbindResult", boxService.unbindDevice(imei));
		return jsonObject;
	}
	
	
	@RequestMapping(value="/boxManage/sitetodevice", method = RequestMethod.POST)
	public JSONObject sitetodevice(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "gid") int gid) throws Exception {
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		
		List<BoxInfoVO> boxInfoVOs = new ArrayList<BoxInfoVO>();
		boxInfoVOs = boxService.getBoxInfoBySiteId(gid);
		JSONArray jsonArray = JSONArray.fromObject(boxInfoVOs);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		jsonObject.put("deviceInfo", jsonArray);
		return jsonObject;
	}
	
	
	@RequestMapping(value="/boxManage/qrcodetodevice", method = RequestMethod.POST)
	public JSONObject qrcodetodevice(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "imei") String imei) throws Exception {
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		
		List<BoxInfoVO> boxInfoVOs = new ArrayList<BoxInfoVO>();
		boxInfoVOs = boxService.getBoxInfoByImei(imei);
		JSONArray jsonArray = JSONArray.fromObject(boxInfoVOs);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		jsonObject.put("deviceInfo", jsonArray);
		return jsonObject;
	}
	

	@RequestMapping(value = "/boxManage/fuzzycityorsite")
	public JSONObject fuzzycityorsite(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "city") String city) throws Exception {
		int type=0;
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		if (type==1) {
			if (city==null || city.equals("")) {
				List<String> citylist = new ArrayList<String>();
				citylist = boxService.selectCity();
				JSONArray jsonArray = JSONArray.fromObject(citylist);
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("status", 1);
				jsonObject.put("info", jsonArray);
				return jsonObject;
			} else {
				List<String> sitelist = new ArrayList<String>();
				sitelist = boxService.selectSitename(city);
				JSONArray jsonArray = JSONArray.fromObject(sitelist);
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("status", 1);
				jsonObject.put("info", jsonArray);
				return jsonObject;
			}
		}
		if (type==2 || type==3) {
//			city= adminPO.getCity();
			List<String> sitelist = new ArrayList<String>();
			sitelist = boxService.selectSitename(city);
			JSONArray jsonArray = JSONArray.fromObject(sitelist);
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 1);
			jsonObject.put("info", jsonArray);
			return jsonObject;
		}
		return null;
	}
	
	
	
	@RequestMapping(value = "/boxManage/infoModify", method = RequestMethod.POST)
	public JSONObject boxinfomodify(
			@RequestParam(value = "Authorization") String token,
			@RequestParam(value = "imei") String imei,
			@RequestParam(value = "mark") String mark,
			@RequestParam(value = "sitename") String sitename) throws Exception {
		/* ************************* Token验证*************************************
		AdminPO adminPO = JWT.unsign(clientToken, AdminPO.class);
		if (adminPO == null) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}
		if (!adminService.authConfirm(adminPO.getType(), "/box/info")) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", 0);
			return jsonObject;
		}		
		**************************************************************************/
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 1);
		jsonObject.put("modifyResult", boxService.modifyDeviceInfo(mark, sitename, imei));
		return jsonObject;
	}
}
