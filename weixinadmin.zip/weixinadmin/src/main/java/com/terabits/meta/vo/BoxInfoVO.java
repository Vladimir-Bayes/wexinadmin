package com.terabits.meta.vo;

public class BoxInfoVO {
	private String mark;
	private String selfnumber;
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	public String getSelfnumber() {
		return selfnumber;
	}
	public void setSelfnumber(String selfnumber) {
		this.selfnumber = selfnumber;
	}
}
