package com.terabits.meta.po;

public class BoxPO {
	private int gid;
	private String imei;
	private String deviceid;
	private String webid;
	private String selfnumber;
	private int chargetype;
	private String type;
	private String mark;
	private String version;
	private int status;
	private int activation;
	private int siteid;
	private String sitename;
	private String simid;
	private double simremain;
	private String gmtcreate;
	private String gmtactivation;
	public int getGid() {
		return gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}
	public String getWebid() {
		return webid;
	}
	public void setWebid(String webid) {
		this.webid = webid;
	}
	public String getSelfnumber() {
		return selfnumber;
	}
	public void setSelfnumber(String selfnumber) {
		this.selfnumber = selfnumber;
	}
	public int getChargetype() {
		return chargetype;
	}
	public void setChargetype(int chargetype) {
		this.chargetype = chargetype;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getActivation() {
		return activation;
	}
	public void setActivation(int activation) {
		this.activation = activation;
	}
	public int getSiteid() {
		return siteid;
	}
	public void setSiteid(int siteid) {
		this.siteid = siteid;
	}
	public String getSitename() {
		return sitename;
	}
	public void setSitename(String sitename) {
		this.sitename = sitename;
	}
	public String getSimid() {
		return simid;
	}
	public void setSimid(String simid) {
		this.simid = simid;
	}
	public double getSimremain() {
		return simremain;
	}
	public void setSimremain(double simremain) {
		this.simremain = simremain;
	}
	public String getGmtcreate() {
		return gmtcreate;
	}
	public void setGmtcreate(String gmtcreate) {
		this.gmtcreate = gmtcreate;
	}
	public String getGmtactivation() {
		return gmtactivation;
	}
	public void setGmtactivation(String gmtactivation) {
		this.gmtactivation = gmtactivation;
	}

}
